<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BukuController extends Controller
{
    public function index()
    {
        $buku = DB::table('buku')->join('kategori', 'buku.kategori_id', '=', 'kategori.kategori_id')->where('buku.buku_id', '1')->get();

        return view('buku', ['buku' => $buku]);
    }
}
