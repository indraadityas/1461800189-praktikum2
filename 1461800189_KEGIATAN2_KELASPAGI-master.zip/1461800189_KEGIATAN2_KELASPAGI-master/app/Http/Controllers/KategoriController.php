<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KategoriController extends Controller
{
    public function index()
    {
        $cari = 'Komputer';
        $kategori = DB::table('kategori')->where('kategori_nama', 'LIKE', '%'.$cari.'%')->get();

        return view('kategori', ['kategori' => $kategori]);
    }
}
