<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PinjamController extends Controller
{
    public function index()
    {
        $cari = '1';
        $pinjam = DB::table('pinjam')
        ->select(['pinjam.pinjam_id', 'anggota.anggota_nama'])
        ->join('anggota', 'pinjam.anggota_id', '=', 'anggota.anggota_id')
        ->where('pinjam.pinjam_id', 'like', '%' .$cari. '%')
        ->get();

        return view('pinjam', ['pinjam' => $pinjam]);
    }
}