@extends ('template')

@section('content')
<div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>Indra Aditiya S.</h2>
                <h3>Soal Nomer 1</h3>
                <h3>Table Anggota</h3>
            </div>
            <div class="float-right">
                <button type="submit" class="btn btn-success">Create</button>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">ID Anggota</th>
            <th class="text-center">Nama</th>
            <th class="text-center">Alamat</th>
            <th class="text-center">JK</th>
            <th class="text-center">Telp</th>
            <th class="text-center">Action</th>
        </tr>
        @foreach ($anggota as $ang)
        <tr>
            <td class="text-center">{{ $ang->anggota_id }}</td>
            <td>{{ $ang->anggota_nama }}</td>
            <td>{{ $ang->anggota_alamat }}</td>
            <td>{{ $ang->anggota_jk }}</td>
            <td>{{ $ang->anggota_telp }}</td>
            <td>
                <button type="submit" class="btn btn-warning">Edit</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        @endforeach
    </table>