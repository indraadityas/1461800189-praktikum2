@extends ('template')

@section('content')
<div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>Indra Aditiya S.</h2>
                <h3>Soal Nomer 3</h3>
                <h3>Table Buku</h3>
            </div>
            <div class="float-right">
                <a class="btn btn-success"> Create Post</a>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">ID Buku</th>
            <th class="text-center">Judul</th>
            <th class="text-center">Kategori</th>
            <th class="text-center">Deskripsi</th>
            <th class="text-center">Jumlah</th>
            <th class="text-center">Cover</th>
        </tr>
        @foreach ($buku as $bk)
        <tr>
            <td>{{ $bk->buku_id }}</td>
            <td>{{ $bk->buku_judul }}</td>
            <td>{{ $bk->kategori_id }}</td>
            <td>{{ $bk->buku_deskripsi }}</td>
            <td>{{ $bk->buku_jumlah }}</td>
            <td>{{ $bk->buku_cover }}</td>
            <td>
                <button type="submit" class="btn btn-warning">Edit</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        @endforeach
    </table>