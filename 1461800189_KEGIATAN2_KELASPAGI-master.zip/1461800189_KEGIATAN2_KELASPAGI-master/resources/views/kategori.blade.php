@extends ('template')

@section('content')
<div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>Indra Aditiya S.</h2>
                <h3>Soal Nomer 2</h3>
                <h3>Table Kategori</h3>
            </div>
            <div class="float-right">
                <button type="submit" class="btn btn-success">Create</button>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">ID Kategori</th>
            <th class="text-center">Nama</th>
        </tr>
        @foreach ($kategori as $ktg)
        <tr>
            <td class="text-center">{{ $ktg->kategori_id }}</td>
            <td>{{ $ktg->kategori_nama }}</td>
            <td>
                <button type="submit" class="btn btn-warning">Edit</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        @endforeach
    </table>