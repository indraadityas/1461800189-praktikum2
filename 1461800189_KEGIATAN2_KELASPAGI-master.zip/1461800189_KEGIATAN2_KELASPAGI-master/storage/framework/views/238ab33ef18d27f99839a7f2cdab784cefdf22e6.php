

<?php $__env->startSection('content'); ?>
<div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>Indra Aditiya S.</h2>
                <h3>Soal Nomer 1</h3>
                <h3>Table Anggota</h3>
            </div>
            <div class="float-right">
                <button type="submit" class="btn btn-success">Create</button>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">ID Anggota</th>
            <th class="text-center">Nama</th>
            <th class="text-center">Alamat</th>
            <th class="text-center">JK</th>
            <th class="text-center">Telp</th>
            <th class="text-center">Action</th>
        </tr>
        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($ang->anggota_id); ?></td>
            <td><?php echo e($ang->anggota_nama); ?></td>
            <td><?php echo e($ang->anggota_alamat); ?></td>
            <td><?php echo e($ang->anggota_jk); ?></td>
            <td><?php echo e($ang->anggota_telp); ?></td>
            <td>
                <button type="submit" class="btn btn-warning">Edit</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\coba2\resources\views/anggota.blade.php ENDPATH**/ ?>