

<?php $__env->startSection('content'); ?>
<div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>Indra Aditiya S.</h2>
                <h3>Soal Nomer 4</h3>
                <h3>Table Pinjam</h3>
            </div>
            <div class="float-right">
                <button type="submit" class="btn btn-success">Create</button>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">ID Kategori</th>
            <th class="text-center">Nama</th>
        </tr>
        <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($pjm->pinjam_id); ?></td>
            <td><?php echo e($pjm->anggota_nama); ?></td>
            <td>
                <button type="submit" class="btn btn-warning">Edit</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\coba2\resources\views/pinjam.blade.php ENDPATH**/ ?>