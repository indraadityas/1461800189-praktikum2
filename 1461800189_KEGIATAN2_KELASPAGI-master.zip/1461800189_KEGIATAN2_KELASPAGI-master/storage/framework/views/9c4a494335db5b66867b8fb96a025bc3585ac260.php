<!DOCTYPE html>
<html>
<head>
    <title>Soal 1</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
 
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
 
</body>
</html><?php /**PATH E:\Laravel\coba2\resources\views/template.blade.php ENDPATH**/ ?>